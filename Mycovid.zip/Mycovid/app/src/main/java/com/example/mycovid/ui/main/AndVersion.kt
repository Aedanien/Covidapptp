package com.example.mycovid.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mycovid.R
import kotlinx.android.synthetic.main.item_and_version.view.*

data class AndVersion(var name: String)
class AndVersionAdapter(val items: Array<AndVersion>) : RecyclerView.Adapter<AndVersionAdapter.ViewHolder>() {

    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        fun bindAndVersion(andVersion: AndVersion) {
            with(andVersion) {
                itemView.andVersionTxt.text = "$name"
            }
        }
        fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bindAndVersion(items[position])
        }
    }
    override fun getItemCount(): Int = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val lineView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_and_version, parent, false)
        return ViewHolder(lineView)
    }
    override fun onBindViewHolder(holder: Any, position: Int) {
        }

    override fun onBindViewHolder(holder: AndVersionAdapter.ViewHolder, position: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}

